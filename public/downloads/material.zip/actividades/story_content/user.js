function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5kaR82MVQ7e":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

